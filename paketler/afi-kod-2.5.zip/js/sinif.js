/* afi kod - sınıf modu
 * Uygulama bir afi sınıf sunucusundan (öğretmen bilgisayarı) ya da öğrenci istemcisinden (afi-istemci) açıldıysa
 * bunu kendisi anlar ve:
 *   - öğrenci, öğretmenin verdiği NUMARAYLA girer: hangi bilgisayara oturursa otursun aynı kayıt açılır,
 *   - öğrencinin ilerlemesini sunucuya gönderir; başka bilgisayarda kaldığı adımdan devam ettirir,
 *   - birkaç saniyede bir canlı durumu (hangi adımda, çalışıyor mu, ne kadardır hareketsiz) gönderir,
 *   - öğretmenin mesajlarını ve "yeni sürüm hazır" bildirimini gösterir, "Yardım iste" düğmesini ekler,
 *   - "Çözümü yükle" düğmesini yalnızca giriş yapmış öğretmene açar.
 * GitHub sayfasında ya da dosyadan açıldığında hiçbir şey yapmaz.
 */
(function (root) {
  'use strict';
  var UYG = 'afi-kod', NABIZ_MS = 8000;
  var S = { aktif: false, bilgi: null, ogretmen: false, bagli: false, api: null, kuyruk: [], zaman: {}, gosterilen: {},
    kip: 'serbest', numara: false, yardim: false, hareket: Date.now(), uyari: {}, pc: [], cihazSon: null, ses: null };
  /* Bu tarayıcının kimliği: öğretmen misafir olarak çalışan bilgisayarlara da mesaj ve komut gönderebilsin */
  var CID = (function () {
    var k = 'afi-cid', v = null;
    try { v = localStorage.getItem(k); if (!v) { v = 'c' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8); localStorage.setItem(k, v); } } catch (e) {}
    return v || ('c' + Math.random().toString(36).slice(2, 10));
  })();
  var KOMUT = {
    'duzen-sifirla': ['Öğretmenin ekran düzenini varsayılana döndürdü.', 'Your teacher reset the screen layout.'],
    'misafir-temizle': ['Öğretmenin misafir çalışmalarını temizledi.', 'Your teacher cleared guest work.'],
    'liste-temizle': ['Öğretmenin bu bilgisayardaki öğrenci listesini temizledi. Numaranla ya da adınla yeniden gir.', 'Your teacher cleared the student list on this computer. Sign in again.']
  };

  function el(tag, cls, html) { var e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  /* Sunucuya istek. Hata olursa sunucunun yazdığı açıklama (varsa) hata.message içinde gelir; hata.kod = HTTP kodu (ağ hatasında 0). */
  function istek(yol, veri, zaman) {
    return new Promise(function (res, rej) {
      var x = new XMLHttpRequest(), bitti = false;
      function hata(kod, mesaj) { var e = new Error(mesaj || String(kod)); e.kod = kod; rej(e); }
      x.open(veri ? 'POST' : 'GET', '/api/v1/' + yol, true);
      x.timeout = zaman || 5000;
      x.setRequestHeader('Content-Type', 'application/json');
      x.onload = function () {
        bitti = true; var j = null;
        try { j = JSON.parse(x.responseText || 'null'); } catch (e) {}
        if (x.status >= 200 && x.status < 300) res(j); else hata(x.status, j && j.hata);
      };
      x.onerror = x.ontimeout = function () { if (!bitti) hata(0, 'ag'); };
      x.send(veri ? JSON.stringify(veri) : null);
    });
  }
  function T(tr, en) { return S.api && S.api.lang() === 'en' ? en : tr; }

  /* ---------- görünüm: bağlantı rozeti, yardım düğmesi, bildirimler ---------- */
  /* Rozetin genişliği sabittir: "bağlı / bağlantı yok" yazısı değişince üst şerit kaymaz. */
  var css = '.sinifchip{display:inline-flex;align-items:center;justify-content:center;gap:6px;height:30px;border-radius:999px;border:1px solid var(--line);background:var(--panel);padding:0 10px;font-size:.78rem;font-weight:800;color:var(--ink-2);white-space:nowrap}' +
    '#sinifChip{min-width:8.6em}' +
    '.sinifchip i{width:9px;height:9px;border-radius:50%;background:var(--ok);display:inline-block;flex:none}.sinifchip[data-off] i{background:var(--lamp)}' +
    'button.sinifchip{cursor:pointer}button.sinifchip:hover{border-color:var(--accent)}' +
    '#sinifYardim{min-width:9.5em}#sinifYardim[aria-pressed="true"]{background:var(--lamp-soft);border-color:var(--lamp);color:var(--ink)}' +
    '.sinifbildirim{position:fixed;right:16px;bottom:16px;z-index:45;display:flex;flex-direction:column;gap:10px;max-width:min(420px,calc(100vw - 32px))}' +
    '.sinifkart{background:var(--panel);border:2px solid var(--accent);border-radius:14px;padding:12px 14px;box-shadow:0 10px 30px rgba(0,0,0,.18);display:flex;flex-direction:column;gap:8px;animation:sinifgir .25s ease-out}' +
    '.sinifkart b{font-family:var(--f-display);font-weight:600}.sinifkart p{margin:0;color:var(--ink);font-size:1rem;white-space:pre-wrap}.sinifkart .row{display:flex;gap:8px;justify-content:flex-end}' +
    '.sinifkart .buyukno{font-family:var(--f-mono);font-size:1.9rem;font-weight:600;letter-spacing:.12em;color:var(--accent)}' +
    '@keyframes sinifgir{from{transform:translateY(20px);opacity:0}to{transform:none;opacity:1}}';
  function rozet(bagli) {
    var c = document.getElementById('sinifChip');
    if (!c) {
      var st = el('style'); st.textContent = css; document.head.appendChild(st);
      c = el('span', 'sinifchip'); c.id = 'sinifChip';
      var tools = document.querySelector('.tools'); if (tools) tools.insertBefore(c, tools.firstChild);
    }
    var degisti = S.bagli !== bagli;
    S.bagli = bagli;
    c.innerHTML = '<i></i>' + esc(bagli ? T('Sınıfa bağlı', 'In class') : T('Bağlantı yok', 'Offline'));
    c.title = bagli ? (S.bilgi && S.bilgi.ad || '') : T('Çalışmaya devam edebilirsin; bağlantı gelince her şey gönderilir.', 'You can keep working; everything is sent when the connection is back.');
    if (bagli) c.removeAttribute('data-off'); else c.setAttribute('data-off', '');
    if (S.bilgi && S.bilgi.rol === 'istemci' && !c.onclick) {      /* öğrenci istemcisi: tıklayınca bağlantı ayarları */
      c.style.cursor = 'pointer'; c.setAttribute('role', 'button'); c.tabIndex = 0;
      c.onclick = function () { window.open('/durum', '_blank'); };
    }
    if (degisti && S.api && S.api.sinifDegisti) S.api.sinifDegisti();
  }
  function panelDugmesi(ad) {
    if (document.getElementById('sinifPanel')) return;
    var c = document.getElementById('sinifChip'), b = el('a', 'sinifchip', '◧ ' + esc(T('Öğretmen paneli', 'Teacher panel')));
    b.id = 'sinifPanel'; b.href = '/panel/'; b.target = '_blank'; b.rel = 'noopener'; b.style.textDecoration = 'none'; b.title = ad || '';
    if (c && c.parentNode) c.parentNode.insertBefore(b, c.nextSibling);
  }
  /* "Yardım iste": öğretmenin panelinde öğrencinin kartı işaretlenir. Öğretmen gelince ya da öğrenci vazgeçince kapanır. */
  function yardimDugmesi() {
    var b = document.getElementById('sinifYardim'), goster = S.aktif && !S.ogretmen && !!kimlik();
    if (!b) {
      if (!goster) return;
      b = el('button', 'sinifchip'); b.id = 'sinifYardim'; b.type = 'button';
      var c = document.getElementById('sinifChip'); if (c && c.parentNode) c.parentNode.insertBefore(b, c.nextSibling);
      b.onclick = function () {
        S.yardim = !S.yardim; S.yardimYerel = Date.now(); yardimDugmesi();
        api.olay(S.yardim ? 'yardim' : 'yardim-iptal');
        if (S.yardim) bildir(T('Öğretmenine haber verildi', 'Your teacher has been notified'), T('Beklerken görevi bir kez daha oku ve denemeye devam et.', 'While you wait, read the task again and keep trying.'));
      };
    }
    b.hidden = !goster;
    b.setAttribute('aria-pressed', String(!!S.yardim));
    b.textContent = '✋ ' + (S.yardim ? T('Yardım istendi', 'Help requested') : T('Yardım iste', 'Ask for help'));
    b.title = S.yardim ? T('Vazgeçmek için tıkla', 'Click to cancel') : T('Takıldıysan öğretmenine haber ver', 'Let your teacher know you are stuck');
  }
  function kutu() {
    var k = document.getElementById('sinifBildirim');
    if (!k) { k = el('div', 'sinifbildirim'); k.id = 'sinifBildirim'; k.setAttribute('role', 'status'); document.body.appendChild(k); }
    return k;
  }
  /* kalici: öğrenci Tamam'a basana kadar durur (öğretmen mesajı, numara). Diğer bilgi kartları 12 saniyede kendiliğinden kapanır;
     aynı anda en çok 3 kart görünür ki çalışma alanı kapanmasın. */
  function bildir(baslik, metin, dugmeler, ekHtml, kalici) {
    var kart = el('div', 'sinifkart', '<b>' + esc(baslik) + '</b>' + (ekHtml || '') + (metin ? '<p>' + esc(metin) + '</p>' : '') + '<div class="row"></div>');
    if (!kalici && !dugmeler) { kart.setAttribute('data-gecici', ''); setTimeout(function () { kart.remove(); }, 12000); }
    var gecici = kutu().querySelectorAll('[data-gecici]');
    if (kutu().children.length >= 3 && gecici.length) gecici[0].remove();
    var sira = kart.querySelector('.row');
    (dugmeler || [{ ad: T('Tamam', 'OK') }]).forEach(function (d) {
      var b = el('button', 'btn btn-small ' + (d.ana ? 'btn-primary' : 'btn-ghost'), esc(d.ad)); b.type = 'button';
      b.onclick = function () { kart.remove(); if (d.f) d.f(); };
      sira.appendChild(b);
    });
    kutu().appendChild(kart);
    if (root.SOUNDS) root.SOUNDS.play('pop');
    return kart;
  }
  function birKez(ad, f) { if (S.uyari[ad]) return; S.uyari[ad] = 1; f(); }

  /* ---------- veri ---------- */
  function kimlik() {
    if (S.ogretmen) return null;          /* öğretmen derste gösterirken öğrenci listesine girmez */
    var p = S.api && S.api.profil();
    if (!p || p.id === 'guest') return null;
    var k = { ad: p.name, robot: S.api.robot(), pid: p.id };
    if (p.kayit) k.kayit = p.kayit;       /* numarayla girmiş öğrenci: sunucudaki kaydı */
    return k;
  }
  /* İki kaydı birleştirir. Yıldızda büyük olan kalır. "sifir": öğretmenin ilerlemeyi sıfırladığı an; daha eski veri atılır.
     "last" (kalınan adım): gezinme sayacı (lastN) büyük olan tarafınki geçerlidir; bu bilgisayarda hiç kayıt yoksa (taze) sunucununki. */
  function birlestir(yerel, uzak, taze) {
    if (!uzak) return yerel;
    yerel = yerel || {};
    /* "Baştan başla" sunucuya henüz ulaşmadı: sunucudaki eski yıldızlar bu kayda karışmaz */
    if (yerel.sifirla && (uzak.sifir || 0) <= (yerel.sifir || 0)) return yerel;
    if ((uzak.sifir || 0) > (yerel.sifir || 0)) return JSON.parse(JSON.stringify(uzak));
    var out = JSON.parse(JSON.stringify(yerel)); out.stars = out.stars || {}; out.ws = out.ws || {}; out.seen = out.seen || {};
    if ((yerel.sifir || 0) > (uzak.sifir || 0)) return out;
    Object.keys(uzak.stars || {}).forEach(function (k) { out.stars[k] = Math.max(out.stars[k] || 0, uzak.stars[k] || 0); });
    Object.keys(uzak.ws || {}).forEach(function (k) { if (!out.ws[k]) out.ws[k] = uzak.ws[k]; });
    Object.keys(uzak.seen || {}).forEach(function (k) { out.seen[k] = true; });
    if (uzak.last && (taze || !out.last || (uzak.lastN || 0) > (out.lastN || 0))) { out.last = uzak.last; out.lastN = Math.max(uzak.lastN || 0, out.lastN || 0); }
    return out;
  }
  function ilerlemeVerisi(tam) {
    var p = S.api.pdata(), veri = { stars: p.stars, seen: p.seen, last: p.last, lastN: p.lastN || 0, sifir: p.sifir || 0, ws: {} };
    if (p.sifirla) veri.sifirla = p.sifirla;
    if (tam) veri.ws = p.ws; else { var cur = S.api.adim().id; if (p.ws[cur]) veri.ws[cur] = p.ws[cur]; }
    return veri;
  }
  function ilerlemeGonder(tam) {
    var k = kimlik(); if (!k) return;
    var veri = ilerlemeVerisi(tam);
    istek('ilerleme', { uygulama: UYG, ogrenci: k, veri: veri }).then(function (c) {
      if (veri.sifirla && c && c.veri && c.veri.sifir && S.api.sifirOnay) S.api.sifirOnay(c.veri.sifir, veri.sifirla);
    }).catch(function () { S.bekleyenTam = true; });
  }
  /* Sunucudaki kaydı getirir ve bu bilgisayardakiyle birleştirir. taze: bu bilgisayarda bu öğrencinin kaydı yoktu -> kaldığı adıma gidilir. */
  function ilerlemeGetir(taze, sessiz) {
    var k = kimlik(); if (!k) return Promise.resolve();
    var q = 'ilerleme?uygulama=' + UYG + '&ad=' + encodeURIComponent(k.ad) + '&robot=' + encodeURIComponent(k.robot) + '&pid=' + encodeURIComponent(k.pid) + (k.kayit ? '&kayit=' + k.kayit : '');
    return istek(q).then(function (c) {
      if (c && c.kimlik) kimlikIsle(c.kimlik, true);
      if (c && c.veri) {
        var yerel = S.api.pdata(), once = JSON.stringify(yerel.stars), sifirlandi = (c.veri.sifir || 0) > (yerel.sifir || 0), yeni = birlestir(yerel, c.veri, taze);
        var git = (taze || sifirlandi || yeni.last !== yerel.last);
        S.api.pdataYaz(yeni, git);
        if (sifirlandi && !taze) bildir(T('İlerlemen sıfırlandı', 'Your progress was reset'), T('Öğretmenin kaydını baştan başlattı.', 'Your teacher restarted your record.'));
        else if (!sessiz && JSON.stringify(yeni.stars) !== once) bildir(T('İlerlemen geldi', 'Your progress is here'), T('Sınıftaki kaydın bu bilgisayara aktarıldı. Kaldığın yerden devam edebilirsin.', 'Your class record was loaded on this computer. You can continue where you left off.'));
      }
      ilerlemeGonder(true);
    }).catch(function () { S.bekleyenTam = true; });
  }
  /* Sunucudan gelen kimlik (numara, ad, sınıf) profile işlenir. Öğretmen adı düzelttiyse ya da numara verdiyse öğrenci görür. */
  function kimlikIsle(k, acilis) {
    if (!S.api.kimlikGeldi) return;
    var s = S.api.kimlikGeldi(k, acilis) || {};
    if (s.yeniNumara) bildir(T('Öğrenci numaran', 'Your student number'),
      T('Bu numarayı bir yere yaz. Başka bir bilgisayara oturduğunda numaranla girersen kaldığın yerden devam edersin.', 'Write this number down. Enter it on any other computer to continue where you left off.'),
      null, '<span class="buyukno">' + esc(k.no) + '</span>', true);
    if (s.adDegisti) bildir(T('Adın güncellendi', 'Your name was updated'), k.ad);
    yardimDugmesi();
  }
  /* Öğretmenin ses ayarı: kapalıysa robot sesleri ve sesli okuma kapanır */
  function sesIsle(deger) {
    if (!deger || !S.api.sesKilit) return;
    var once = S.ses; S.ses = deger;
    if (S.api.sesKilit(deger) && once) bildir(deger === 'kapali' ? T('Öğretmenin sesi kapattı', 'Your teacher turned the sound off') : T('Öğretmenin sesi açtı', 'Your teacher turned the sound on'), '');
  }
  /* Öğrenci girmemişken (giriş ekranı ya da misafir): ses ayarı, herkese giden mesajlar ve komutlar */
  function cihazNabiz() {
    if (S.ogretmen || kimlik()) return;
    var v = { uygulama: UYG, cid: CID }; if (S.cihazSon != null) v.son = S.cihazSon;
    istek('cihaz', v, 6000).then(function (c) {
      c = c || {};
      rozet(!c.cevrimdisi);
      if (c.cevrimdisi) return;
      if (c.son != null) S.cihazSon = c.son;
      if (c.kip && c.kip !== S.kip) { S.kip = c.kip; if (S.api.sinifDegisti) S.api.sinifDegisti(); }
      sesIsle(c.ses);
      (c.mesajlar || []).forEach(mesaj);
      if (c.surum && root.AFI_VERSION && c.surum !== root.AFI_VERSION) surumHazir(c.surum);
    }).catch(function () { rozet(false); });
  }
  function nabiz(ek) {
    var k = kimlik(); if (!k) { if (!ek) cihazNabiz(); return; }
    var d = S.api.adim(), olaylar = S.kuyruk.splice(0, 40);
    var v = { uygulama: UYG, ogrenci: k, cihaz: { ad: S.bilgi && S.bilgi.cihaz || '', istemci: S.bilgi && S.bilgi.rol === 'istemci', ip: S.bilgi && S.bilgi.ip },
      adim: { id: d.id, ad: d.ad, yildiz: d.adimYildiz || 0 }, durum: d.durum, yildiz: d.yildiz, biten: d.biten, olaylar: olaylar,
      saat: Date.now() / 1000, bos: Math.round((Date.now() - S.hareket) / 1000), cid: CID };
    if (ek) Object.keys(ek).forEach(function (a) { v[a] = ek[a]; });
    istek('nabiz', v, 6000).then(function (c) {
      c = c || {};
      rozet(!c.cevrimdisi);
      if (c.kip && c.kip !== S.kip) { S.kip = c.kip; if (S.api.sinifDegisti) S.api.sinifDegisti(); }
      if (c.giris_gerekli) {             /* öğretmen "yalnızca numarayla giriş" kipini açmış */
        if (S.api.cikisYap) S.api.cikisYap();
        birKez('giris', function () { bildir(T('Numaranla gir', 'Enter with your number'), T('Bu sınıfta öğretmenin verdiği öğrenci numarasıyla giriliyor.', 'In this class you sign in with the student number your teacher gave you.')); });
        return;
      }
      if (!c.cevrimdisi && 'kimlik' in c) kimlikIsle(c.kimlik, false);
      if (!c.cevrimdisi) sesIsle(c.ses);
      if (S.bekleyenTam && !c.cevrimdisi) { S.bekleyenTam = false; ilerlemeGetir(false, true); }
      if (!c.cevrimdisi && c.sifir && c.sifir > (S.api.pdata().sifir || 0)) ilerlemeGetir(false, true);
      if (!c.cevrimdisi && 'yardim' in c && Date.now() - (S.yardimYerel || 0) > 3000 && !!c.yardim !== S.yardim) {
        var once = S.yardim; S.yardim = !!c.yardim; yardimDugmesi();
        if (once && !S.yardim) bildir(T('Öğretmenin yardım isteğini gördü', 'Your teacher saw your help request'), '');
      }
      if (c.cakisma) birKez('cakisma', function () {
        bildir(T('Aynı adla başka biri bağlı', 'Someone else is using this name'), T('Başka bir bilgisayarda da aynı ad ve aynı robotla giriş var. Kayıtlarınız karışmasın diye öğretmeninden numara iste ya da adına soyadının ilk harfini ekle.',
          'Another computer is signed in with the same name and robot. Ask your teacher for a number, or add your initial to your name, so your records do not mix.'));
      });
      (c.mesajlar || []).forEach(mesaj);
      if (c.surum && root.AFI_VERSION && c.surum !== root.AFI_VERSION) surumHazir(c.surum);
    }).catch(function () { S.kuyruk = olaylar.concat(S.kuyruk).slice(0, 120); rozet(false); });
  }
  function mesaj(m) {
    if (S.gosterilen[m.id]) return; S.gosterilen[m.id] = 1;
    if (m.tur === 'komut') {
      var km = KOMUT[m.metin]; if (!km || !S.api.komut) return;
      var uygula = function () { if (S.api.komut(m.metin)) bildir(T(km[0], km[1]), ''); };
      if (m.metin === 'liste-temizle' && kimlik()) { ilerlemeGonder(true); setTimeout(uygula, 1500); }      /* önce son çalışma gönderilir */
      else uygula();
      return;
    }
    if (m.tur === 'surum') { var v = String(m.metin || '').split(' ')[1]; if (v && v !== root.AFI_VERSION) surumHazir(v); return; }
    bildir(T('Öğretmenden mesaj', 'Message from your teacher') + (m.gonderen ? ' · ' + m.gonderen : ''), m.metin, null, null, true);
  }
  function surumHazir(v) {
    if (S.surumBildirildi === v) return; S.surumBildirildi = v;
    bildir(T('Yeni sürüm hazır: ', 'New version ready: ') + v, T('Kaldığın yer kaydedildi. Yenilemek için düğmeye bas.', 'Your work is saved. Press the button to reload.'),
      [{ ad: T('Sonra', 'Later') }, { ad: T('Şimdi yenile', 'Reload now'), ana: true, f: function () { S.api.kaydet(); if (S.api.yenidenAc) S.api.yenidenAc(); setTimeout(function () { location.reload(); }, 150); } }]);
  }
  /* Sayfa kapanırken ya da yenilenirken: son çalışmayı ve "çıktı" bilgisini tarayıcı kapanmadan yollar. */
  function veda() {
    var k = kimlik(); if (!k || !navigator.sendBeacon) return;
    try {
      S.api.kaydet();
      var d = S.api.adim();
      navigator.sendBeacon('/api/v1/ilerleme', new Blob([JSON.stringify({ uygulama: UYG, ogrenci: k, veri: ilerlemeVerisi(false) })], { type: 'application/json' }));
      navigator.sendBeacon('/api/v1/nabiz', new Blob([JSON.stringify({ uygulama: UYG, ogrenci: k, cihaz: { ad: S.bilgi && S.bilgi.cihaz || '', istemci: S.bilgi && S.bilgi.rol === 'istemci', ip: S.bilgi && S.bilgi.ip },
        adim: { id: d.id, ad: d.ad, yildiz: d.adimYildiz || 0 }, durum: d.durum, yildiz: d.yildiz, biten: d.biten, olaylar: S.kuyruk.splice(0, 40), saat: Date.now() / 1000, cikis: true, cid: CID })], { type: 'application/json' }));
    } catch (e) {}
  }

  /* ---------- uygulamanın çağırdığı işlevler ---------- */
  var api = {
    aktif: function () { return S.aktif; },
    ogretmen: function () { return S.ogretmen; },
    bagli: function () { return S.bagli; },
    /* Sunucu öğrenci numarasını destekliyor mu? (afi sınıf 1.3 ve sonrası) */
    numara: function () { return S.aktif && S.numara && !S.ogretmen; },
    /* 'serbest': adını yazarak da girilir.  'numara': yalnızca öğretmenin verdiği numarayla girilir. */
    kip: function () { return S.aktif && S.numara && !S.ogretmen ? S.kip : 'serbest'; },
    baglan: function (a) {
      S.api = a;
      if (!/^https?:$/.test(location.protocol) || /github\.io$/i.test(location.hostname)) return;
      istek('bilgi', null, 2500).then(function (b) {
        if (!b || b.sistem !== 'afi-sinif') return;
        S.aktif = true; S.bilgi = b; S.kip = b.giris_kipi || 'serbest'; S.numara = (b.ozellikler || []).indexOf('numara') >= 0;
        rozet(b.rol !== 'istemci' || !!b.sunucu_bagli);
        istek('ben').then(function (k) {
          S.ogretmen = !!(k && k.ogretmen); a.ogretmenDegisti(S.ogretmen);
          if (S.ogretmen) panelDugmesi(k.ad);
          else if (/^#(ogretmen|teacher)$/i.test(location.hash) && b.rol !== 'istemci')
            bildir(T('Öğretmen modu', 'Teacher mode'), T('Sınıfta "Çözümü yükle" düğmesi, öğretmen paneline giriş yapınca açılır. Panelde "AFİ KOD\'u aç" düğmesini kullanın.', 'In class, the solution button is available after signing in to the teacher panel. Use "Open AFI CODE" in the panel.'),
              [{ ad: T('Kapat', 'Close') }, { ad: T('Öğretmen paneli', 'Teacher panel'), ana: true, f: function () { location.href = '/panel/'; } }]);
          if (a.sinifDegisti) a.sinifDegisti();
          yardimDugmesi();
        }).catch(function () {});
        ['pointerdown', 'keydown', 'wheel', 'pointermove'].forEach(function (olay) {
          root.addEventListener(olay, function () { S.hareket = Date.now(); }, { passive: true, capture: true });
        });
        document.addEventListener('visibilitychange', function () { if (!document.hidden) nabiz(); });
        root.addEventListener('pagehide', veda);
        if (a.sinifDegisti) a.sinifDegisti();
        api.pcYenile().then(function () { if (a.sinifDegisti) a.sinifDegisti(); });      /* giriş penceresi açıksa "bu bilgisayarda girenler" gelsin */
        if (a.profil()) api.profilAcildi(!a.pdata().last);
        setInterval(nabiz, NABIZ_MS);
        setTimeout(nabiz, 800);
        a.ogretmenDegisti(false);
      }).catch(function () {});
    },
    /* Numarayla giriş: öğrencinin adı, robotu ve sınıfı sunucudan gelir. */
    girisNo: function (no) {
      return istek('ogrenci-giris', { no: String(no || '').replace(/\D/g, '') }, 7000).then(function (c) { return c.kimlik; }, function (e) {
        if (!e.kod) throw new Error(T('Öğretmen bilgisayarına ulaşılamadı. Biraz sonra yeniden dene.', 'Could not reach the teacher computer. Try again in a moment.'));
        if (e.kod === 404 && e.message === '404') throw new Error(T('Bu sunucu numarayla girişi desteklemiyor.', 'This server does not support number sign-in.'));
        throw e;
      });
    },
    /* Profil açılınca: sunucudaki ilerlemeyi getir, birleştir, sonra tamamını gönder. taze: bu bilgisayarda bu profilin kaydı yoktu. */
    profilAcildi: function (taze) {
      if (!S.aktif) return;
      S.yardim = false; S.uyari.cakisma = 0; yardimDugmesi();
      if (!kimlik()) return;
      ilerlemeGetir(!!taze);
      nabiz();
    },
    /* Numarasız öğrenci robotunu değiştirince kayıt yeni kimliğe taşınır; numaralı öğrencide yalnızca robot seçimi kaydedilir. */
    kimlikDegisti: function (eski) {
      if (!S.aktif) return;
      var k = kimlik(); if (!k || !eski) return;
      eski.pid = k.pid; if (k.kayit) eski.kayit = k.kayit;
      istek('kimlik', { uygulama: UYG, eski: eski, yeni: k }).then(function (c) {
        if (c && c.dolu) {
          if (S.api.robotGeriAl) S.api.robotGeriAl(eski.robot);
          bildir(T('Bu robot dolu', 'That robot is taken'), T('Senin adınla ve bu robotla başka bir öğrenci var. Başka bir robot seç ya da öğretmeninden numara iste.', 'Another student uses your name with this robot. Pick a different robot or ask your teacher for a number.'));
          return;
        }
        ilerlemeGonder(true);
      }).catch(function () { ilerlemeGonder(true); });
    },
    kaydedildi: function () {
      if (!S.aktif) return;
      clearTimeout(S.zaman.il); S.zaman.il = setTimeout(function () { ilerlemeGonder(false); }, 2500);
    },
    calismaDegisti: function () {
      if (!S.aktif) return;
      clearTimeout(S.zaman.an); S.zaman.an = setTimeout(function () {
        var k = kimlik(); if (!k) return;
        var d = S.api.adim();
        istek('anlik', { uygulama: UYG, ogrenci: k, adim: d.id, ws: S.api.pdata().ws[d.id] || null, kod: S.api.kod() }).catch(function () {});
      }, 2500);
    },
    olay: function (tur, ayrinti) {
      if (!S.aktif) return;
      S.kuyruk.push({ zaman: Date.now() / 1000, tur: tur, adim: S.api.adim().id, ayrinti: ayrinti || null });
      clearTimeout(S.zaman.nb); S.zaman.nb = setTimeout(nabiz, 600);
    },
    /* Bu bilgisayarda daha önce girenler (sunucudan): tarayıcı kayıtları silinse de öğrenci adını bulur */
    pcYenile: function () {
      if (!S.aktif || S.ogretmen) return Promise.resolve();
      return istek('bu-bilgisayar?uygulama=' + UYG, null, 5000).then(function (c) { S.pc = (c && c.ogrenciler) || []; }).catch(function () {});
    },
    pcListesi: function () { return S.aktif && !S.ogretmen && S.kip !== 'numara' ? S.pc : []; },
    girisKayit: function (kid) {
      return istek('ogrenci-giris', { kayit: kid }, 7000).then(function (c) { return c.kimlik; }, function (e) {
        throw new Error(e.kod ? e.message : T('Öğretmen bilgisayarına ulaşılamadı. Biraz sonra yeniden dene.', 'Could not reach the teacher computer. Try again in a moment.'));
      });
    },
    /* "Baştan başla": sıfırlama isteği hemen gönderilir */
    sifirlandi: function () { if (S.aktif && kimlik()) ilerlemeGonder(true); },      /* sunucu olaylara kendisi yazar */
    _birlestir: birlestir      /* testler için */
  };
  root.SINIF = api;
})(typeof window !== 'undefined' ? window : this);
